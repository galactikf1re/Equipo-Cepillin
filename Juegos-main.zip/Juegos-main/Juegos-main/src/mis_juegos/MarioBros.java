package mis_juegos;
/*
 * Equipo:
 * Rogelio Centeno Sanchez 
 * Juan Pablo Martin del Campo Rodriguez
 * Juan Pablo Ramos Bogarin
 * Jesus Antonio Gandara Alcantara
 */
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.util.ArrayList;
import java.awt.event.*;
//

public class MarioBros extends JPanel implements Runnable {
	
	private BufferedImage mapa1;
	private BufferedImage mapa2;

    //private Image mapa1;
    private int scrollX = 0; // se utiliza para aumentar el valor de X y asi avanza el mapa.
    private int velocidad = 3; //el valor que le se le da a esta variable es la cantidad de pixele que llevara la velocidad

    private Image game_over;
    private boolean mostrarGameOver = false;

    private Image personaje;   // Imagen actual
    private Image quieto;      // Imagen cuando está parado
    private Image corriendo;
    private Image exp;// Imagen cuando corre

    private int personajeX = 40, personajeY = 170; // posición inicial del personaje
    private boolean iniciar_juego = true;

    // Arreglo para guaradar las coordenadas que nos regresa el metodo colisionesMapa1() que esta en la clase Colisiones
    private ArrayList<Rectangle> colisiones_mapa1 = new ArrayList<>();
    private ArrayList<Rectangle> colisionesfin = new ArrayList<>();

    public MarioBros() {
        // Cargar imágenes
        corriendo = new ImageIcon("imagenes_mario/correr2.gif").getImage();
        quieto = new ImageIcon("imagenes_mario/stop.gif").getImage();
        exp = new ImageIcon("imagenes_mario/explosion.gif").getImage();
        
        
        game_over = new ImageIcon("imagenes_mario/game-over-game.gif").getImage();
        
        //mapa1 = new ImageIcon("imagenes_mario/mapa1.png").getImage();
        
        //creamos una varibla de tipo BufferedImage este tipo de imagen nos ayuda a controlar mejor los pixeles
        //la variables de tipo Image solo se utilizan para plasmar una imagen normal en la ventana
        // y es mas recomendable usar de tipo BufferedImage para este caso del mejor control de nuestro mapa por pixeles
        
        //utilizamos try para el control de los posibles errores , 
        try {
        	mapa1 = ImageIO.read(getClass().getResource("/mis_juegos/mapas/mapa1.png"));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error en el mapa" + e );
        }
        
        try {
        	mapa2 = ImageIO.read(getClass().getResource("/mis_juegos/mapas/mapa2.png"));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error en el mapa" + e );
        }

        personaje = quieto;


        setPreferredSize(new Dimension(1000, 240)); // fijar el tamaño de la ventana 
        
        //Escuchar las teclas, con este método lo configuramos para que reciba solo entradas por teclado
        setFocusable(true);

        // Hilo principal del juego, se agrega en el Constructor para ejecutar el hilo en cuanto cargue el juego
        new Thread(this).start(); // Hilo para el Mapa actual

        // Controles de teclado
        addKeyListener(new KeyAdapter() {
            @Override
            
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    personaje = corriendo;
                    personajeX+=3;
                    repaint();
                    
                }
                
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    personaje = corriendo;
                    personajeY-=3;
                    repaint();
                }
                
                if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    personaje = corriendo;
                    personajeY+=3;
                    repaint();
                }
                
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    personaje = corriendo;
                    personajeX-=3;
                    repaint();
                }
                
            }
            @Override
            public void keyReleased(KeyEvent e) {
                personaje = quieto;
                repaint();
            }
        });
    }

    @Override
    public void run() {
        while (iniciar_juego) {
            scrollX += velocidad; //aqui estamos aumentando de 3 en 3 pixeles. para que el mapa valla recorriendo en posicion de X

            
            int realX = scrollX + personajeX;
            //creamos un rectangulo para marcar al personaje con un tamaño de 200x200 y este va tomando 
            //las posiciones de realX que se construye en la linea anterior.
            Rectangle jugador = new Rectangle(realX, personajeY, 40, 40); 
            
            /*estamos creando una instancia a la clase Colisiones*/
            Colisiones objeto_colision1 = new Colisiones();
            colisiones_mapa1 = objeto_colision1.colisionesMapa1();
            
            Colisiones objeto_colision3 = new Colisiones();
            colisionesfin = objeto_colision3.colisionesfin();
            
            //recorremos el for para sacar las posiciones de la colisión
            for (Rectangle zona : colisiones_mapa1) {
            	
            	//si el jugador esta en la misma posicion es porque esta a la misma altura que la colision
            	// el método intersects(recibe las coordenadas del rectangulo) 
            	// intersects es un método de la clase Rectangle 
                if (jugador.intersects(zona)) { 
                    System.out.println("Colisión detectada en zona " + zona);
                    mostrarGameOver = true;
                    setFocusable(false);
                    personaje = exp;
                    velocidad = 0;        // detiene el scroll dejando en 0 la velocidad
                    iniciar_juego = false; // se detiene el bucle
                    repaint();
                    break;
                }
            }
                
                for (Rectangle zona3 : colisionesfin) {
                	
                	//si el jugador esta en la misma posicion es porque esta a la misma altura que la colision
                	// el método intersects(recibe las coordenadas del rectangulo) 
                	// intersects es un método de la clase Rectangle 
                    if (jugador.intersects(zona3)) { 
                        System.out.println("Colisión detectada en zona " + zona3);
                        repaint();
                        break;
                    }
            }

            repaint();

            try {
                Thread.sleep(70);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Dibuja el mapa con desplazamiento
        g.drawImage(mapa1, -scrollX, 0, null);

        // Dibuja el personaje
        g.drawImage(personaje, personajeX, personajeY, this);

        // Mostrar imagen de Game Over si hay colisión
        if (mostrarGameOver) {
        	 /* estamos creando una posición para acomodar la imagen de game over en el centro
        	  * de la ventana, optenemos el ancho y alto y dividimos entre 2 restando 100 pixeles 
        	  * para que esta quede justo en el centro*/
            int posX = getWidth() / 2 - 100;
            int posY = getHeight() / 2 - 100;
            g.drawImage(game_over, posX, posY, 200, 200, null);
        }
        
        
        Colisiones objeto_colision = new Colisiones();
        colisiones_mapa1 = objeto_colision.colisionesMapa1();
        
        Colisiones objeto_colision3 = new Colisiones();
        colisionesfin = objeto_colision3.colisionesMapa1();
        
        // Dibujar zonas de colision
        g.setColor(new Color(0, 255, 0, 100)); //aplicamos el color del rectangulo
        for (Rectangle zona : colisiones_mapa1) {
            g.fillRect(zona.x - scrollX, zona.y, zona.width, zona.height);
        }
    }

    public static void main(String[] args) {
        JFrame ventana = new JFrame("Juego de Mario Bros FAKE");
        MarioBros juego = new MarioBros();
        ventana.add(juego);
        ventana.pack(); //ajusta automáticamente el tamaño de la ventana al tamaño que se define en el constructor.
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
    }
}
