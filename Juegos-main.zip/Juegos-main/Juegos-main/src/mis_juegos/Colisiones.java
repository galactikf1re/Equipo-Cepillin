package mis_juegos;

import java.awt.Rectangle;
import java.util.ArrayList;

public class Colisiones {
    // Lista de zonas de colisión
    private ArrayList<Rectangle> colisiones = new ArrayList<>();
    
    //constructor, este siempre lleva el nombre de nuestra clase.
    public Colisiones() {}
    
    /* 
     * en este metodo definiciones las colisiones del mapa 1 / nivel 1.
     * estamos retornando un ArrayList de tipo Rectangle para regresar la posicion completa 
     * de la coordenada de la figura, usamos este tipo porque estamos
     * dibujando una figura de rectangulo y esta recibe 4 parametros (x, y, ancho, alto)
     * 
     * */
    public ArrayList<Rectangle> colisionesMapa1() {
    	
    	 // Definir zonas de colisión (x, y, ancho, alto)
        colisiones.add(new Rectangle(255, 230, 2000, 25));
        colisiones.add(new Rectangle(389, 145, 115, 11));
        colisiones.add(new Rectangle(418, 82, 70, 11));
        colisiones.add(new Rectangle(515, 193, 40, 11));
        colisiones.add(new Rectangle(561, 129, 70, 11));
        colisiones.add(new Rectangle(643, 66, 95, 11));
        colisiones.add(new Rectangle(804, 210, 53, 11));
        colisiones.add(new Rectangle(962, 83, 60, 11));
        colisiones.add(new Rectangle(944, 210, 70, 11));
        colisiones.add(new Rectangle(1043, 211, 70, 11));
        colisiones.add(new Rectangle(1122, 143, 42, 11));
        colisiones.add(new Rectangle(1219, 96, 90, 11));
        colisiones.add(new Rectangle(1570, 175, 58, 12));
        colisiones.add(new Rectangle(1660, 112, 123, 14));
        colisiones.add(new Rectangle(290, 192, 58, 14));
        colisiones.add(new Rectangle(1811, 209, 43, 14));
        colisiones.add(new Rectangle(1857, 145, 59, 12));
        colisiones.add(new Rectangle(1954, 145, 60, 11));




        

        
        return colisiones;
    }
    
    public ArrayList<Rectangle> colisionesMapa2() {
    	
   	 // Definir zonas de colisión (x, y, ancho, alto)
       colisiones.add(new Rectangle(255, 230, 2000, 25));

       
       return colisiones;
   }
    
    public ArrayList<Rectangle> colisionesfin() {
   	
  	 // Definir zonas de colisión (x, y, ancho, alto)
      colisiones.add(new Rectangle(255, 170, 40, 40));

      
      return colisiones;
  }

}
