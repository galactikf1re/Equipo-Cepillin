/**
 * 
 */
/**
 * 
 */
module Juegos {
	requires java.desktop;
}